
public class MainDB {

	public static void main(String[] args)
	{
		new InterfacciaGrafica();
		new Query();
		
		// TODO Auto-generated method stub

	}

}
