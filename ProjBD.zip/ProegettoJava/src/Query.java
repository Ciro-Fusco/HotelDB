

import java.sql.*;

import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Query {
	 
	private static Connection con = null ;
	public static String connessione () {

	  try {
			  //caricamento e registrazione driver
			   Class.forName("com.mysql.cj.jdbc.Driver"); //Carica il Driver
			   String url ="jdbc:mysql://localhost:3306/hotel?useSSL=false&serverTimezone=UTC";
		       String username = "root";
			   String pwd = "ci1ro23456";  
			   con = DriverManager.getConnection(url,username,pwd);
			   return "Connessione riuscita,ora puoi proedere con l'esecuzione delle query";
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
		  return "Connessione non riuscita";
		 
	  }
	}
	
	public static String uscita()  {
		
		try {
			con.close();
			return "Connessione chiusa correttamente\n";
		} catch (SQLException e) {
			return "Chiusura connessione fallita\n";
		}
	}
	
	public static void query1(String codice_fiscale,String nome,String cognome,String nascita, String numero , String check_in, String check_out)  {
   	
    try {
    		String sql3 = "SELECT *\n" + 
				"FROM Prenotazione\n" + 
				"WHERE numero = ? AND((? BETWEEN check_in AND check_out) OR (? BETWEEN check_in AND check_out));";
    		PreparedStatement queryC = con.prepareStatement(sql3);
    		queryC.setString(1,numero);
    		queryC.setString(2,check_in);
    		queryC.setString(3,check_out);
    		ResultSet res = queryC.executeQuery();
    		if(res.last() == false) {
   			String sql="INSERT INTO Cliente(codice_fiscale,nome,cognome,data_di_nascita) VALUES (?,?,?,?);";
   			String sql2="INSERT INTO Prenotazione(codice_fiscale,numero,check_in,check_out) VALUES (?,?,?,?);";
	        PreparedStatement query = con.prepareStatement(sql);
	        PreparedStatement query2 = con.prepareStatement(sql2);
	        query.setString(1, codice_fiscale);
	        query.setString(2, nome);
	        query.setString(3, cognome);
	        query.setString(4, nascita);
	        query2.setString(1, codice_fiscale);
	        query2.setString(2 ,numero);
	        query2.setString(3, check_in);
	        query2.setString(4, check_out);
	        query.executeUpdate();
	        query2.executeUpdate();
            query.close();
            query2.close();
    		}
    		else {
    			throw new SQLException();
    		}
            
         }
    catch (SQLException e)
    {
       System.out.println(e);
       JPanel pane= new JPanel();
       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
    }
}
	
	public static void query2(String CF,String nome,String cognome,String nascita, String anni,String lingua,String radio) {

		    try {
		    	
		   			String sql = "INSERT INTO personale(codice_fiscale,nome,cognome,data_di_nascita) VALUES (?,?,?,?);";
		   			String sql2= "INSERT INTO cuochi(codice_fiscale,anni_esperienza) VALUES (?,?);";
		   			String sql3= "INSERT INTO camerieri(codice_fiscale) VALUES (?);";
		   			String sql4= "INSERT INTO reception(codice_fiscale) VALUES (?);";
		   			String sql5= "INSERT INTO parla(codice_fiscale,lingua_parlata) VALUES(?,?);";
		   			String sql6= "INSERT INTO inservienti(codice_fiscale) VALUES (?);";
		   			String sql7= "DELETE FROM personale WHERE codice_fiscale =?;";
			        PreparedStatement query = con.prepareStatement(sql);
			        PreparedStatement query2 = con.prepareStatement(sql2);
			        PreparedStatement query3 = con.prepareStatement(sql3);
			        PreparedStatement query4 = con.prepareStatement(sql4);
			        PreparedStatement query5 = con.prepareStatement(sql5);
			        PreparedStatement query6 = con.prepareStatement(sql6);
			        PreparedStatement query7 = con.prepareStatement(sql7);
			        query.setString(1, CF);
			        query.setString(2, nome);
			        query.setString(3, cognome);
			        query.setString(4, nascita);
			        query2.setString(1, CF);
			        query2.setString(2,anni);
			        query3.setString(1, CF);
			        query4.setString(1, CF);
			        query5.setString(1, CF);
			        query5.setString(2, lingua);
			        query6.setString(1,CF);
			        query7.setString(1, CF);
			        if(radio.equals("Cuoco")) {
			        	if(Integer.parseInt(anni)<3) throw new NumberFormatException();
			        	else {
			        	query.executeUpdate();
			        	query2.executeUpdate();
			        	query.close();
			        	query2.close();
			        	}
			        }
			        else if(radio.equals("Cameriere")) {
			        	query.executeUpdate();
			        	query3.executeUpdate();
			        	query3.close();
			        	query.close();
			        	
			        }
			        else if(radio.equals("Reception")) {
			        	query.executeUpdate();
			        	query4.executeUpdate();
			        	query5.executeUpdate();
			        	query4.close();
			        	query5.close();
			        	query.close();
			        	
			        }
			        else if(radio.equals("Inserviente")) {
			        	query.executeUpdate();
			        	query6.executeUpdate();
			        	query6.close();
			        	query.close();
			        }
			        else if(radio.equals("Delete")) {
			        	query7.executeUpdate();
			        	query7.close();
			        	}
		         }

		    catch (NumberFormatException |SQLException e )
		    {
		       System.out.println(e);
		       JPanel pane= new JPanel();
		       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
		    
		    }
		
	}
	
	public static void query3(String nome,String indirizzo,String nome_ristorante,String data_fornitura) {

		 try {
	   			String sql="INSERT INTO fornitore(nome,indirizzo) VALUES(?,?);";
	   			String sql2 = "INSERT INTO fornitura(nome,nome_ristorante,data_fornitura) VALUES (?,?,?);";
	   			PreparedStatement query = con.prepareStatement(sql);
	   			PreparedStatement query2 = con.prepareStatement(sql2);
		        query.setString(1, nome);
		        query.setString(2, indirizzo);
		        query2.setString(1,nome );
		        query2.setString(2, nome_ristorante);
		        query2.setString(3 , data_fornitura);
		        query.executeUpdate();
		        query2.executeUpdate();
	            query.close();
	            query2.close();
	         }
	    catch (SQLException e)
	    {
	       System.out.println(e);
	       JPanel pane= new JPanel();
	       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
	    }	
	}
	
	public static String query4() {
		String r="";

		try {
   			Statement query = con.createStatement();
	        ResultSet result = query.executeQuery("Select * from portata;");
	    
	        while (result.next())
            {
               String nome =result.getString("codice")+" / "+ result.getString("nome");
               r+=nome+"\n";
          
            } 
            result.close();
            query.close();
            return r;
         }
    catch (SQLException e)
    {
    	e.printStackTrace();
       return null;
    }	
		
	}

	public static void query5(int codice,String nome_menu,String nome_portata) {

		try {
   			
			
			;

   			String sql="INSERT INTO menu(codice,tipo) VALUES(?,?);";
	        String sql2="INSERT INTO Portata(codice,nome) VALUES(?,?)";
   			PreparedStatement query = con.prepareStatement(sql);
   			PreparedStatement query2 = con.prepareStatement(sql2);
	        query.setInt(1, codice);
	        query.setString(2, nome_menu);
	        query2.setInt(1, codice);
	        query2.setString(2,nome_portata);
	        
	        query.executeUpdate();
	        query2.executeUpdate();
	        query2.close();
            query.close();
         }
    catch (SQLException e)
    {
       System.out.println(e);
       JPanel pane= new JPanel();
       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
    }	
		
	}
	
	public static void query6(String data_inizio, String ora_inizio, int durata_turno, String CF ) {

		try {
			String sql = "INSERT INTO Turno(data,ora_inizio,durata) VALUES (?,?,?);";
			String sql2 ="INSERT INTO Effettua(data,ora_inizio,codice_fiscale)  VALUES(?,?,?);";
			PreparedStatement query = con.prepareStatement(sql);
			PreparedStatement query2 = con.prepareStatement(sql2);
	        query.setString(1,data_inizio);
	        query.setString(2,ora_inizio);
	        query.setInt(3,durata_turno);
	        query2.setString(1,data_inizio);
	        query2.setString(2,ora_inizio);
	        query2.setString(3, CF);
	        query.executeUpdate();
	        query2.executeUpdate();
	        query.close();
	        query2.close();
	        
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
    }
	}
	
	
	
	public static void query6b(String data_inizio, String ora_inizio,String CF ) {

		try {
			String sql2 ="INSERT INTO Effettua(data,ora_inizio,codice_fiscale)  VALUES(?,?,?);";
			PreparedStatement query2 = con.prepareStatement(sql2);
	        query2.setString(1,data_inizio);
	        query2.setString(2,ora_inizio);
	        query2.setString(3, CF);
	        query2.executeUpdate();
	        query2.close();
	        
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
    }
	}
	
	
	
	public static String query7(String numero) {
		String r="";
		try {
	        String sql="SELECT COUNT(*) FROM Prenotazione WHERE Numero = ?;";
	        PreparedStatement query = con.prepareStatement(sql);
	        query.setString(1,numero);
	        ResultSet result = query.executeQuery();
	    
            while (result.next())
            {
               r+= result.getString(1);
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
    	e.printStackTrace();
        return null;
 
    }
	}
	
public static String query8(String data_i,String data_f) {

		
		String s="Nessun risultato";
		String r="";
		boolean c=false;
		try {
	        
	        String sql = "SELECT codice_fiscale,SUM(durata) "
	        		+ "FROM Turno ,EFFETTUA " +
	        		"WHERE (Turno.data BETWEEN ? AND ?) AND EFFETTUA.data=Turno.data AND EFFETTUA.ora_inizio=Turno.ora_inizio " + 
	        		"GROUP BY EFFETTUA.codice_fiscale;";
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1, data_i);
	       query.setString(2, data_f);
	       ResultSet result= query.executeQuery();
	       
            while (result.next())
            {  
            	c=true;
               r+=result.getString(1)+"\t" + result.getString(2)+"\n";
            } 
            result.close();
            query.close();
            if(c)
            return r;
            else
            return s;
           
       }
    catch (SQLException e)
    {
    	e.printStackTrace();
        return null;
    }
		
	}
	
	public static String query9() {

		String r="";
		try {
	        
	        String sql = "SELECT * FROM Fornitore;";
	       PreparedStatement query = con.prepareStatement(sql);
	       ResultSet result= query.executeQuery();
	       
            while (result.next())
            {  
            String codice= result.getString("nome");
               r+=codice+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
    	e.printStackTrace();
        return null;
    }
		
	}
	
	public static String query10(String num, String codice_fisc, String in, String out) {

		String r="";
		
		String s_in=in.substring(0,10);
		String s_out=out.substring(0,10);
		if(s_in.contentEquals(s_out)) throw new NumberFormatException();
		else {
		try {
			String sql2 = "SELECT *\n" + 
					"FROM Prenotazione\n" + 
					"WHERE numero = ? AND((? BETWEEN check_in AND check_out) OR (? BETWEEN check_in AND check_out));";
			PreparedStatement queryC = con.prepareStatement(sql2);
			queryC.setString(1,num);
			queryC.setString(2,in);
			queryC.setString(3,out);
			ResultSet res = queryC.executeQuery();
			if(res.last() == false) {
	        String sql="INSERT INTO prenotazione(numero, codice_fiscale, check_in, check_out) VALUES (?,?,?,?);";
	        PreparedStatement query = con.prepareStatement(sql);
	        query.setString(1,num);
	        query.setString(2,codice_fisc);
	        query.setString(3,in);
	        query.setString(4,out);
	        query.executeUpdate();
            query.close();
            return r;
            }
			else {
				throw new SQLException();
			}
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }
	}
	}
	public static String query11(String nome_ristorante) {

		String r="";
		try {
	        
	        String sql = "SELECT COUNT(*) as numOccupati \n" + 
	        		"FROM USUFRUISCE_DI\n" + 
	        		"WHERE USUFRUISCE_DI.nome_ristorante =?;";
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1,nome_ristorante);
	       ResultSet result= query.executeQuery();
	       
            while (result.next())
            {  
            String codice= result.getString("numOccupati");
               r+=codice+"\n\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
        System.out.println(e);
        JPanel pane= new JPanel();
        JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
        return null;
    }

	}
	
	public static int query12() {
		
		int res = 0;
		try {
	        
	        Statement query = con.createStatement();
	        ResultSet result = query.executeQuery("SELECT Count(*) AS numpersonale\r\n " + "FROM personale\r\n;");
	        
	        while (result.next())
            {  
	        	res = Integer.parseInt(result.getString("numpersonale"));
          
            }
            result.close();
            query.close();
            return res;
           
       }
    catch (SQLException e)
    {
    	e.printStackTrace();
        return 0;
    }
	}
	
	public static String query13(String data) {
		
		String r="";
		try {
	        
	        String sql = "SELECT P.nome,P.codice_fiscale \n" + 
	        		"FROM Personale AS P\n" + 
	        		"WHERE NOT EXISTS (\n" + 
	        		"SELECT *\n" + 
	        		"FROM EFFETTUA AS E , Turno AS T\n" + 
	        		"WHERE E.codice_fiscale = P.codice_fiscale AND T.ora_inizio = E.ora_inizio AND E.data = T.data AND T.data= ? );" ;
	        
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1,data);
	       ResultSet result= query.executeQuery();
	       
            while (result.next())
            {  
            String dipententi =result.getString("nome") + " / " + result.getString("codice_fiscale");
            r += dipententi + "\n";
          
            } 
            result.close();
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
    	e.printStackTrace();
        return null;
    }
	}
	
	public static String query14(String check_in , String check_out) {

		String r="";
		try {
	        
	        String sql = "SELECT C.nome,C.codice_fiscale\n" + 
	        		"FROM Cliente AS C , Prenotazione AS P\n" + 
	        		"WHERE C.codice_fiscale = P.codice_fiscale AND P.check_in =? AND P.check_out =?\n" ;
	       PreparedStatement query = con.prepareStatement(sql);
	       query.setString(1,check_in);
	       query.setString(2, check_out);
	       ResultSet result= query.executeQuery();
	       while (result.next())
           {  
           String pren =result.getString("nome") +"\t"+ result.getString("codice_fiscale"); 
           r += pren + "\n";
         
           } 
            query.close();
            return r;
           
       }
    catch (SQLException e)
    {
    	e.printStackTrace();
        return null;
    }
		
		
	}
	
	public static String query15() {
		String r ="";
		try {
			
			Statement query= con.createStatement();
			ResultSet res = query.executeQuery("SELECT R.nome_ristorante\n" + 
					"FROM Fornitore AS F , Fornitura AS FR, Ristorante AS R\n" + 
					"WHERE F.nome =FR.nome AND FR.nome_ristorante= R.nome_ristorante\n" + 
					"GROUP BY R.nome_ristorante\n" + 
					"HAVING COUNT(*)>3;");
			
			while (res.next())
	           {  
	           String pren =res.getString("nome_ristorante");
	           r += pren + "\n";
	         
	           } 
	            query.close();
	            return r;
			
		}
		catch(SQLException e) {
			e.printStackTrace();
		       return null;
		}
	}	
}
	
