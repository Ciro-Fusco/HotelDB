

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class InterfacciaGrafica extends JFrame {

	private JPanel contentPane;

 
	public InterfacciaGrafica() {
		super("Gestione Hotel");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JTextArea Results = new JTextArea();
		Results.setEditable(false);
		Results.setText("                                                         ^^^\n"
				+ "                                                         | | |\n"
				+ "\nPrima di poter effettuare le query � necessario connettersi al DB\nattraverso il bottone apposito.\nPer avere informazioni sulle query trascina\nil cursore sul bottone corrispondente.");
		JScrollPane scrollV = new JScrollPane(Results);
		scrollV.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollV, BorderLayout.CENTER);
		
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(8,2));
		contentPane.add(buttonpanel, BorderLayout.SOUTH);
		
		JButton buttonQuery1 = new JButton("Query 1");
		buttonQuery1.setToolTipText("Aggiunge un nuovo cliente");
		buttonQuery1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JFrame tmp= new JFrame();
				tmp.setVisible(true);
				tmp.setTitle("Aggiungi un nuovo cliente");
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 250);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(7,1));
				panel1.add(new JLabel("Codice fiscale"));
				panel1.add(new JLabel("Nome"));
				panel1.add(new JLabel("Cognome"));
				panel1.add(new JLabel("Inserire data di nascita aaaa-mm-gg"));
				panel1.add(new JLabel("Numero di Camera"));
				panel1.add(new JLabel("Data check_in"));
				panel1.add(new JLabel("Data check_out"));
				tmp.add(panel1);
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				JTextField t4= new JTextField();
				JTextField t5= new JTextField();
				JTextField t6= new JTextField();
				JTextField t7= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(7,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				panel.add(t5);
				panel.add(t6);
				panel.add(t7);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Query.query1(t1.getText(),t2.getText(),t3.getText(),t4.getText(),t5.getText(),t6.getText(),t7.getText());
						Results.setText("Cliente aggiunto");
						tmp.dispose();
					}
				});
				tmp.add(btn);
				
				}
		});
		
		buttonpanel.add(buttonQuery1);
		
		JButton buttonQuery2 = new JButton("Query 2");
		buttonQuery2.setToolTipText("Aggiunge un nuovo membro del personale");
		buttonQuery2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setTitle("Aggiungi un nuovo membro al personale");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(870, 230);
				tmp.setLayout(new GridLayout(1,4));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(6,1));
				panel1.add(new JLabel("Codice Fiscale:"));
				panel1.add(new JLabel("Nome:"));
				panel1.add(new JLabel("Cognome:"));
				panel1.add(new JLabel("Data di nascita:"));
				panel1.add(new JLabel("Anni Esperienza (Cuochi):"));
				panel1.add(new JLabel("Lingua parlata (Reception):"));
				ButtonGroup radio = new ButtonGroup();
				JRadioButton cuochi = new JRadioButton("Cuoco");
				cuochi.setActionCommand("Cuoco");
				JRadioButton cameriere = new JRadioButton("Cameriere");
				cameriere.setActionCommand("Cameriere");
				JRadioButton reception = new JRadioButton("Reception");
				reception.setActionCommand("Reception");
				JRadioButton inserviente = new JRadioButton("Inserviente");
				inserviente.setActionCommand("Inserviente");
				JRadioButton delete = new JRadioButton("Elimina (Necessario solo CF)");
				delete.setActionCommand("Delete");
				radio.add(cuochi);
				radio.add(cameriere);
				radio.add(reception);
				radio.add(inserviente);
				radio.add(delete);
				JPanel panel2 = new JPanel();
				panel2.setVisible(true);
				panel2.setLayout(new GridLayout(5,1));
				panel2.add(cuochi);
				panel2.add(cameriere);
				panel2.add(reception);
				panel2.add(inserviente);
				panel2.add(delete);
				tmp.add(panel2);
				tmp.add(panel1);
				
				JTextField t1 = new JTextField();
				JTextField t2 = new JTextField();
				JTextField t3 = new JTextField();
				JTextField t4 = new JTextField();
				JTextField t5 = new JTextField();
				JTextField t6 = new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(6,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				panel.add(t5);
				panel.add(t6);
				tmp.add(panel);
				
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try {
						Query.query2(t1.getText(),t2.getText(),t3.getText(),t4.getText(),t5.getText(),t6.getText(),radio.getSelection().getActionCommand());
						Results.setText("Azione eseguita");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				 
				tmp.add(btn);
				
			}
		});
		buttonpanel.add(buttonQuery2);
		JButton buttonQuery3 = new JButton("Query 3");
		buttonQuery3.setToolTipText("Aggiunge un nuovo fornitore con prima fornitura");
		buttonQuery3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setTitle("Aggiunge un nuovo fornitore con prima fornitura");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 170);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(4,1));
				panel1.add(new JLabel("Nome Fornitore"));
				panel1.add(new JLabel("Indirizzo fornitore"));
				panel1.add(new JLabel("Nome ristorante"));
				panel1.add(new JLabel("Data fornitura"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				JTextField t4= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(4,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						
						try{
							Query.query3(t1.getText(),t2.getText(),t3.getText(),t4.getText());
						Results.setText("Fornitore e prima fornitura aggiunti");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
				
				}
		});
		buttonpanel.add(buttonQuery3);
		JButton buttonQuery4 = new JButton("Query 4");
		buttonQuery4.setToolTipText("Stampa portate di ogni men�");
		buttonQuery4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText("Portate presenti nei men�:\nCodice men� / Nome portata\n" + Query.query4());
				
				
			}
		});
		buttonpanel.add(buttonQuery4);
		
		JButton buttonQuery5 = new JButton("Query 5");
		buttonQuery5.setToolTipText("Aggiunge un nuovo men� con prima portata");
		buttonQuery5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setTitle("Aggiungi un nuovo men� con prima portata");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 150);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(3,1));
				panel1.add(new JLabel("Codice men� (10 cifre)"));
				panel1.add(new JLabel("Nome men�"));
				panel1.add(new JLabel("Nome prima portata"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				t1.setToolTipText("10 cifre");
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Query.query5(Integer.parseInt(t1.getText()),t2.getText(),t3.getText());
						Results.setText("Squadra aggiunta!!");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
				
			}
		});
		buttonpanel.add(buttonQuery5);
		
		JButton buttonQuery6= new JButton("Query 6");
		buttonQuery6.setToolTipText("Aggiunge un nuovo turno");
		buttonQuery6.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setTitle("Aggiungi un nuovo turno");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 150);
				tmp.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(4,1));
				panel1.add(new JLabel("Data del turno:"));
				panel1.add(new JLabel("Ora inizio del turno:"));
				panel1.add(new JLabel("Durata del turno:"));
				panel1.add(new JLabel("Turno effettuato da (Codice Fiscale Personale):"));
				tmp.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				JTextField t4= new JTextField();
				
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(4,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				panel.add(t4);
				tmp.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Query.query6(t1.getText(),t2.getText(),Integer.parseInt(t3.getText()), t4.getText());
						Results.setText("Turno aggiunto.");
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
			}
		});
		
		buttonpanel.add(buttonQuery6);
		
		
		
		JButton buttonQuery6b= new JButton("Query 7");
		buttonQuery6b.setToolTipText("Assegna turno a dipendente");
		buttonQuery6b.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame frm= new JFrame();
				frm.setTitle("Assegna turno a dipendente");
				frm.setVisible(true);
				frm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				frm.setSize(850, 150);
				frm.setLayout(new GridLayout(1,3));
				
				JPanel panel1 = new JPanel();
				panel1.setVisible(true);
				panel1.setLayout(new GridLayout(3,1));
				panel1.add(new JLabel("Data del turno:"));
				panel1.add(new JLabel("Ora inizio del turno:"));
				panel1.add(new JLabel("Turno effettuato da (Codice Fiscale Personale):"));
				frm.add(panel1);
				
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				JTextField t3= new JTextField();
				
				
				JPanel panel = new JPanel();
				panel.setVisible(true);
				panel.setLayout(new GridLayout(3,1));
				panel.add(t1);
				panel.add(t2);
				panel.add(t3);
				frm.add(panel);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Query.query6b(t1.getText(),t2.getText(), t3.getText());
						Results.setText("Turno aggiunto.");
						frm.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				frm.add(btn);
			}
		});
		
		buttonpanel.add(buttonQuery6b);
		
		
		JButton buttonQuery7= new JButton("Query 8");
		buttonQuery7.setToolTipText("Controlla il numero di volte in cui � stata prenotata una camera");
		buttonQuery7.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setTitle("Controlla il numero di volte in cui � stata prenotata una camera");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 100);
				tmp.setLayout(new GridLayout(1,3));
				
				tmp.add(new JLabel("Numero"));
				
				
				JTextField t1= new JTextField();
				
				tmp.add(t1);
				
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						Results.setText(Query.query7(t1.getText()));
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(btn);
			}
		});
		
		buttonpanel.add(buttonQuery7);
		
		JButton buttonQuery8= new JButton("Query 9");
		buttonQuery8.setToolTipText("Controlla il numero di ore lavorative dei dipendenti in un intervallo");
		buttonQuery8.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				JPanel pn = new JPanel();
				tmp.setTitle("Controlla il numero di ore lavorative dei dipendenti in un intervallo");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(600, 200);
				tmp.setLayout(new GridLayout(1,3));
				
				pn.setLayout(new GridLayout(2,1));
				
				pn.add(new JLabel("Data inizio intervallo"));
				
				
				pn.add(new JLabel("Data fine intervallo"));
	
				JPanel pn1 = new JPanel();
				pn1.setLayout(new GridLayout(2,1));
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();

				pn1.add(t1);
				pn1.add(t2);
				
				
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try{
						;
						Results.setText("Query effettuata\n\n"+ Query.query8(t1.getText(),t2.getText()));
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
				});
				tmp.add(pn);
				tmp.add(pn1);
				tmp.add(btn);
			}
		});
		
		buttonpanel.add(buttonQuery8);
		
		JButton buttonQuery9= new JButton("Query 10");
		buttonQuery9.setToolTipText("Visualizza elenco fornitori");
		buttonQuery9.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
						try{
						Results.setText("Query effettuata \n" + Query.query9());
					
						
						}
						catch(NumberFormatException ex) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
						}
					}
	
			}
		);
		
		buttonpanel.add(buttonQuery9);
		
		
		
		JButton buttonQuery10 = new JButton("Query 11");
		buttonQuery10.setToolTipText("Aggiunge una prenotazione");
		buttonQuery10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFrame tmp= new JFrame();
				tmp.setTitle("Aggiunge una prenotazione");
				tmp.setLayout(new GridLayout(1,3));
				tmp.setVisible(true);
				tmp.setSize(400,150);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				
				JPanel panel= new JPanel();
				panel.setLayout(new GridLayout(4,1));
				JPanel panel1= new JPanel();
				panel1.setLayout(new GridLayout(4,1));
				JLabel l1= new JLabel("Numero camera");
				JLabel l2= new JLabel("Codice Fiscale");
				JLabel l3= new JLabel("Check-in");
				JLabel l4= new JLabel("Check-out");
				
				JTextField f1 = new JTextField();
				JTextField f2 = new JTextField();
				JTextField f3 = new JTextField();
				JTextField f4 = new JTextField();
				
				panel.add(l1);
				panel1.add(f1);
				panel.add(l2);
				panel1.add(f2);
				panel.add(l3);
				panel1.add(f3);
				panel.add(l4);
				panel1.add(f4);
				
				
				JButton btn = new JButton("Invia dati");
				
				tmp.add(panel);
				tmp.add(panel1);
				tmp.add(btn);
				
				btn.addActionListener(new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e)
							{
								
								try 
								{
									Query.query10(f1.getText(),f2.getText(),f3.getText(),f4.getText());
									Results.setText("Inserimento effettuato\n");	
									tmp.dispose();
									
								}
								catch(NumberFormatException ex)
								{
									System.out.println(e);
								       JPanel pane= new JPanel();
								       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
								      
								}
								
								
							}
						});
				
			
			}
		});
		buttonpanel.add(buttonQuery10);
	
		JButton buttonQuery11 = new JButton("Query 12");
		buttonQuery11.setToolTipText("Visualizza posti prenotati di un ristorante");
		buttonQuery11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			JFrame tmp= new JFrame();
			tmp.setTitle("Visualizza posti prenotati di un ristorante");
			tmp.setLayout(new GridLayout(1,3));
			tmp.setVisible(true);
			tmp.setSize(500,50);
			tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			JLabel l1= new JLabel("Nome ristorante");
			JTextField f1 = new JTextField();
			tmp.add(l1);
			tmp.add(f1);
			JButton btn = new JButton("Invia dati");
			tmp.add(btn);
			btn.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e)
						{
							
							try 
							{
					
								Results.setText("Posti occupati per il ristorante "+ f1.getText() +":"+ Query.query11(f1.getText()));	
								tmp.dispose();
							}
							catch(NumberFormatException ex)
							{
								System.out.println(e);
							       JPanel pane= new JPanel();
							       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);
							      
							}
							
							
						}
					});
			}
		});

			
		buttonpanel.add(buttonQuery11);
		
	
		JButton buttonQuery12 = new JButton("Query 13");
		buttonQuery12.setToolTipText("Visualizza numero dipendenti");
		buttonQuery12.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						Results.setText("Numero di dipendenti:" + Query.query12());
					}
				});
		buttonpanel.add(buttonQuery12);
		
		
		
		JButton buttonQuery13 = new JButton("Query 14");
		buttonQuery13.setToolTipText("Visualizza il personale che non ha mai effettuato un dato turno");
		buttonQuery13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setTitle("Visualizza il personale che non ha mai effettuato un dato turno");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(500, 50);
				tmp.setLayout(new GridLayout(1, 3));
				
				tmp.add(new JLabel("Inserisci data"));
				
				
				JTextField t1= new JTextField();
				tmp.add(t1);
			;
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try {
						Results.setText("Personale che non ha mai effettuato il turno in data " + t1.getText() + ":\n" + Query.query13(t1.getText()));
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);	
						}
					}
				});
				tmp.add(btn);
			}
		});
		buttonpanel.add(buttonQuery13);
		
		JButton buttonQuery14 = new JButton("Query 15");
		buttonQuery14.setToolTipText("Visualizza tutte le prenotazioni con le date specifiche di check-in e check-out");
		buttonQuery14.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				JFrame tmp= new JFrame();
				tmp.setTitle("Visualizza tutte le prenotazioni con le date specifiche di check-in e check-out");
				tmp.setVisible(true);
				tmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				tmp.setSize(570, 120);
				tmp.setLayout(new GridLayout(1, 3));
				JPanel pan1 = new JPanel();
				pan1.setLayout(new GridLayout(2,1));
				pan1.add(new JLabel("Inserisci check-in"));
				pan1.add(new JLabel("Inserisci check-out"));
				tmp.add(pan1);
				JPanel pan2 = new JPanel();
				pan2.setLayout(new GridLayout(2,1));
				JTextField t1= new JTextField();
				JTextField t2= new JTextField();
				pan2.add(t1);
				pan2.add(t2);
				tmp.add(pan2);
				JButton btn= new JButton("Invia Dati");
				btn.setVisible(true);
				btn.addActionListener(new ActionListener() {
					
					@Override
					public void actionPerformed(ActionEvent arg0) {
						try {
						Results.setText("Prenotazioni effettuate con data di check-in: "+t1.getText()+" e data check-out: "+t2.getText() + "\n" + Query.query14(t1.getText() , t2.getText()));;
						tmp.dispose();
						}
						catch(NumberFormatException e) {
							System.out.println(e);
						       JPanel pane= new JPanel();
						       JOptionPane.showMessageDialog(pane,"Inserisci i dati correttamente","Dati sbagliati", JOptionPane.ERROR_MESSAGE);	
						}
					}
				});
				tmp.add(btn);
			}
		} );
		buttonpanel.add(buttonQuery14);
		
		JButton btnNewButton_10 = new JButton("Query 16");
		btnNewButton_10.setToolTipText("Visualizza i ristoranti che sono stati riforniti pi� di 3 volte");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText("Ristoranti riforniti pi� di 3 volte:\n" + Query.query15());
				
				
			}
		});
		buttonpanel.add(btnNewButton_10);
		
		JButton exitbutton = new JButton("Chiudi connessione");
		exitbutton.setForeground(Color.RED);
		exitbutton.setToolTipText("Chiudi la connessione con il DB");
		exitbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText(Query.uscita());
				
			}
		});
		
		buttonpanel.add(exitbutton);
	
		JButton connectionButton = new JButton("Effettua connessione");
		connectionButton.setForeground(Color.GREEN);
		connectionButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Results.setText(Query.connessione());
			}
		});
		
		
		
		JPanel btConnectionPanel= new JPanel();
		btConnectionPanel.setVisible(true);
		btConnectionPanel.setLayout(new GridLayout(1,3));
		
		btConnectionPanel.add(new JPanel());
		btConnectionPanel.add(connectionButton);
	
		btConnectionPanel.add(new JPanel());
		
		contentPane.add(btConnectionPanel, BorderLayout.NORTH);
		setVisible(true);
		
	}
	

}
