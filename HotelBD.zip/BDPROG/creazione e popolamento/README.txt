Per il popolamento del database è necessario cambiare il path dei file nella local load data nel file hoteldb.sql
