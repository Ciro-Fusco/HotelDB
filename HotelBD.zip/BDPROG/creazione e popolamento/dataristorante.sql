Rosso Pomodoro,50,2
Capriccio di Mare,50,2
La vela,150,3
Osteria del presidente,100,2
RisRoyale,150,3